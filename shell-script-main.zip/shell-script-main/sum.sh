#!/bin/bash
a=10
b=20
sum=$(( $a + $b ))
echo"sum is: $sum"

